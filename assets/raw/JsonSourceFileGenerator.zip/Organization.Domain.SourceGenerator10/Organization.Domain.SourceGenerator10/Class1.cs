﻿using Microsoft.CodeAnalysis;
using System;
using System.Collections.Generic;
using System.Text;

namespace Organization.Domain.SourceGenerator10
{
    [Generator]
    public class JsonSourceFileGeneratorx : ISourceGenerator
    {
        private string attributeText = @"
using System;
namespace {0}
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
    sealed class JsonSourceFileClassAttribute : Attribute
    {
        public JsonSourceFileClassAttribute()
        {
        }
        public string PropertyName { get; set; }
    }
}
";

        public void Initialize(GeneratorInitializationContext context)
        {
        }

        public void Execute(GeneratorExecutionContext context)
        {
            // Find the main method
            var mainMethod = context.Compilation.GetEntryPoint(context.CancellationToken);
            var namespacex = mainMethod.ContainingNamespace.ToDisplayString();
            // Build up the source code

            var gen = attributeText.Replace("{0}", namespacex);
            //var typeName = mainMethod.ContainingType.Name;

            // Add the source code to the compilation
            context.AddSource("JsonSourceFileClass.g.cs", gen);
        }
    }
}