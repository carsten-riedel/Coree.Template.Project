﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Emit;
using System.Reflection;

namespace Organization.Domain.SourceGenerator10
{
    public class StringCompiler
    {
        public static Dictionary<string, string> AssemblyLocations = new Dictionary<string, string>();

        public List<string> CompileAndExecute(string code,string namespaceName,string typeName,string methodName ,string AssemblyBaseNameSuffix = "")
        {
            List<string> error = new List<string>();

#pragma warning disable RS1035 // Do not use APIs banned for analyzers
            //string code = File.ReadAllText(codePath);
#pragma warning restore RS1035 // Do not use APIs banned for analyzers
            SyntaxTree syntaxTree = CSharpSyntaxTree.ParseText(code);

#pragma warning disable RS1035 // Do not use APIs banned for analyzers
            List<string> Assemblys = new List<string>() { "System", "System.Runtime", "System.Text.Json", "System.Private.CoreLib", "System.IO" , "System.Collections" , "System.Linq" };

            foreach (var item in Assemblys)
            {
                if (!AssemblyLocations.ContainsKey(item))
                {
                    string loc = string.Empty;
                    try
                    {
                        loc = Assembly.Load(item).Location;
                        AssemblyLocations.Add(item, loc);
                    }
                    catch (Exception e)
                    {
                        error.Add($"Assembly could not be found: {item} -> {e.Message} -> {loc}");
                    }
                }
            }
            if (error.Count > 0)
            {
                return error;
            }

            var executableReferences = AssemblyLocations.Values.Distinct().Select(loc => MetadataReference.CreateFromFile(loc)).ToArray();

#pragma warning restore RS1035 // Do not use APIs banned for analyzers

            // if (!Debugger.IsAttached) { Debugger.Launch(); }

            AssemblyName assemblyName = new AssemblyName();
            // Set the properties
            assemblyName.Name = $@"DynamicAssembly{AssemblyBaseNameSuffix}";
            assemblyName.Version = new Version(DateTime.UtcNow.ToString("yyMM.ddHH.mmss.ffff"));

            CSharpCompilation compilation = CSharpCompilation.Create(assemblyName.FullName,new[] { syntaxTree }, executableReferences, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));

            using (var ms = new MemoryStream())
            {
                EmitResult result = compilation.Emit(ms);

                if (!result.Success)
                {
                    foreach (Diagnostic diagnostic in result.Diagnostics)
                    {
                        error.Add($"Diagnostics: {diagnostic.Id}, {diagnostic.GetMessage()}");

#pragma warning disable RS1035 // Do not use APIs banned for analyzers
                        error.AddRange(code.Split(Environment.NewLine.ToCharArray()));
#pragma warning restore RS1035 // Do not use APIs banned for analyzers

                    }
                    return error;
                }

                ms.Seek(0, SeekOrigin.Begin);
#pragma warning disable RS1035 // Do not use APIs banned for analyzers
                Assembly assembly = Assembly.Load(ms.ToArray());
#pragma warning restore RS1035 // Do not use APIs banned for analyzers

                try
                {
                    // Assuming you know the type and method names
                    Type type = assembly.GetType($"{namespaceName}.{typeName}");
                    MethodInfo method = type.GetMethod($"{methodName}");
                    object classInstance = Activator.CreateInstance(type, null);
                    method.Invoke(classInstance, null);
                }
                catch (Exception e)
                {
                    error.Add(code + ": " + e.ToString());
                }
                return error;
            }
        }
    }
}