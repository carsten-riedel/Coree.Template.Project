﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace ConsoleSourceGeneratorConsum
{
    public partial class UserClass : ObservableObject
    {
        [ObservableProperty]
        private bool _boolProp;
    }
}