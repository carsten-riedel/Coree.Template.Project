﻿using Newtonsoft.Json.Linq;
using System.Globalization;

namespace ConsoleApp6
{
    public class CultureSpecificFile
    {
        public string FilePath { get; set; }
        public CultureInfo Culture { get; set; }

        public CultureSpecificFile(string filePath, CultureInfo culture)
        {
            FilePath = filePath;
            Culture = culture;
        }
    }

    public class CultureSpecificFiles
    {
        private List<CultureSpecificFile> files = new List<CultureSpecificFile>();

        public void Add(string filePath, CultureInfo culture)
        {
            files.Add(new CultureSpecificFile(filePath, culture));
        }

        public IEnumerable<CultureSpecificFile> GetFiles()
        {
            return files;
        }

        public JObject MergeApplicableJsonFiles()
        {
            JObject mergedJson = new JObject();
            var applicableFiles = FindAllApplicableMatches();

            foreach (var file in applicableFiles)
            {
                string jsonContent = File.ReadAllText(file.FilePath);
                JObject currentJson = JObject.Parse(jsonContent);

                mergedJson.Merge(currentJson, new JsonMergeSettings
                {
                    MergeArrayHandling = MergeArrayHandling.Union,
                    MergeNullValueHandling = MergeNullValueHandling.Ignore
                });
            }

            return mergedJson;
        }

        public IEnumerable<CultureSpecificFile> FindAllApplicableMatches()
        {
            CultureInfo currentCulture = CultureInfo.CurrentCulture;
            string currentCultureFiveLetterName = currentCulture.Name; // Full culture code (e.g., "de-DE")
            string currentCultureTwoLetterName = currentCulture.TwoLetterISOLanguageName; // Neutral culture code (e.g., "de")

            var result = files.Where(file => file.Culture.Name == currentCultureFiveLetterName ||
                                       file.Culture.TwoLetterISOLanguageName == currentCultureTwoLetterName ||
                                       file.Culture.Equals(CultureInfo.InvariantCulture))
                .OrderBy(file => file.Culture.Name.Length);
            return result;
        }

        public CultureSpecificFile FindBestMatchForCurrentCulture()
        {
            CultureInfo currentCulture = CultureInfo.CurrentCulture;
            string currentCultureTwoLetterName = currentCulture.TwoLetterISOLanguageName;
            CultureSpecificFile defaultFile = null;

            // First loop to find exact culture match
            foreach (var file in files)
            {
                if (file.Culture.Equals(currentCulture))
                {
                    return file; // Specific culture match
                }
            }

            // Second loop to find neutral culture match (based on two-letter ISO language name)
            foreach (var file in files)
            {
                if (file.Culture.TwoLetterISOLanguageName.Equals(currentCultureTwoLetterName))
                {
                    return file; // Neutral culture match
                }
            }

            foreach (var file in files)
            {
                if (file.Culture.Equals(CultureInfo.InvariantCulture))
                {
                    defaultFile = file; // Save the default file for fallback
                }
            }

            // Return default file if no exact or neutral culture match is found
            return defaultFile;
        }

        public CultureSpecificFile FindBestMatchForCurrentCulture2()
        {
            CultureInfo currentCulture = CultureInfo.CurrentCulture;
            string currentCultureFiveLetterName = currentCulture.Name; // Full culture code (e.g., "de-DE")
            string currentCultureTwoLetterName = currentCulture.TwoLetterISOLanguageName; // Neutral culture code (e.g., "de")

            var bestMatch = files
                .Where(file => file.Culture.Name == currentCultureFiveLetterName || // Exact culture match
                               file.Culture.TwoLetterISOLanguageName == currentCultureTwoLetterName || // Neutral culture match
                               file.Culture.Equals(CultureInfo.InvariantCulture)) // Default culture
                .OrderBy(file => file.Culture.Equals(CultureInfo.InvariantCulture)) // Default culture last
                .ThenBy(file => file.Culture.TwoLetterISOLanguageName != currentCultureTwoLetterName) // Neutral culture second
                .FirstOrDefault();

            return bestMatch;
        }

        public CultureSpecificFile GetDefaultFile()
        {
            return files.FirstOrDefault(file => file.Culture.Equals(CultureInfo.InvariantCulture));
        }
    }
}