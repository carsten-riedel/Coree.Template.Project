﻿namespace ConsoleApp6
{
    public static class ObjectInitializer
    {
        public static T NewInitialized<T>(bool initializeNullStrings = false) where T : new()
        {
            // Create a new instance of the specified type
            T instance = new T();

            // Initialize all properties of the instance
            InitializeAllProperties(instance, initializeNullStrings);

            return instance;
        }

        private static void InitializeAllProperties(object obj, bool initializeNullStrings)
        {
            if (obj == null) return;

            // Iterate through all the properties of the object
            foreach (var property in obj.GetType().GetProperties())
            {
                // Check if the property can be written to
                if (property.CanWrite)
                {
                    // Get the type of the property
                    var propertyType = property.PropertyType;

                    // Initialize null strings if the option is enabled
                    if (initializeNullStrings && propertyType == typeof(string) && property.GetValue(obj) == null)
                    {
                        property.SetValue(obj, String.Empty);
                        continue;
                    }

                    // Check if the type is a class and not a string
                    if (propertyType.IsClass && propertyType != typeof(string))
                    {
                        // Create an instance of the property type
                        var propertyInstance = Activator.CreateInstance(propertyType);

                        // Initialize the properties of the subclass recursively
                        InitializeAllProperties(propertyInstance, initializeNullStrings);

                        // Set the property value to the created instance
                        property.SetValue(obj, propertyInstance);
                    }
                }
            }
        }
    }
}