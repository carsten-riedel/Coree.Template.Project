﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoNotify;

namespace ConsoleSourceGeneratorConsum
{
    public partial class UserClass2
    {
        [AutoNotify(PropertyName = "Countx")]
        private int _intProp;
    }
}