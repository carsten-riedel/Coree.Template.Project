﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Emit;
using Microsoft.CSharp;

namespace Organization.Domain.SourceGenerator10
{
    public class DynamicCompiler
    {
        /*
         public void CompileAndExecute(string source,string namespaceClass = "YourNamespace.YourClass", string methodName = "YourMethod")
         {
             CodeDomProvider objCodeCompiler = new Microsoft.CodeDom.Providers.DotNetCompilerPlatform.CSharpCodeProvider();
             CSharpCodeProvider provider = new CSharpCodeProvider();
             CompilerParameters parameters = new CompilerParameters();

             // Add references to assemblies you might need
             parameters.ReferencedAssemblies.Add("System.dll");
 #pragma warning disable RS1035 // Do not use APIs banned for analyzers
             var netstandard = Assembly.Load("netstandard, Version=2.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51");
 #pragma warning restore RS1035 // Do not use APIs banned for analyzers
             parameters.ReferencedAssemblies.Add(netstandard.Location);
             parameters.GenerateExecutable = false; // Set to true if you want an exe
             parameters.GenerateInMemory = true;

             if(!Debugger.IsAttached) {
                 Debugger.Launch();
             }

 #pragma warning disable RS1035 // Do not use APIs banned for analyzers
             System.IO.File.WriteAllText(@"C:\temp\foo.cs", source);
 #pragma warning restore RS1035 // Do not use APIs banned for analyzers

             // Compile the code from the file
             CompilerResults results = provider.CompileAssemblyFromFile(parameters, new string[] { @"C:\temp\foo.cs" });

             if (results.Errors.HasErrors)
             {
                 Console.WriteLine("Compilation errors:");
                 foreach (CompilerError error in results.Errors)
                 {
                     Console.WriteLine(error.ToString());
                 }
             }
             else
             {
                 // Execute the compiled code
                 Assembly compiledAssembly = results.CompiledAssembly;
                 MethodInfo method = compiledAssembly.GetType(namespaceClass).GetMethod(methodName);
                 method.Invoke(null, null); // Assumes a static method with no parameters
             }
         }
       */
    }

    public class CompilerExample
    {
        public void CompileAndExecute(string code)
        {
#pragma warning disable RS1035 // Do not use APIs banned for analyzers
            //string code = File.ReadAllText(codePath);
#pragma warning restore RS1035 // Do not use APIs banned for analyzers
            SyntaxTree syntaxTree = CSharpSyntaxTree.ParseText(code);

#pragma warning disable RS1035 // Do not use APIs banned for analyzers
            var locationOfSystemAssembly = Assembly.Load("System").Location;
            var locationOfSystemRuntimeAssembly = Assembly.Load("System.Runtime").Location;
            var locationOfSystemTextJsonAssembly = Assembly.Load("System.Text.Json").Location;
            var locationOfSystemPrivateCoreLibAssembly = Assembly.Load("System.Private.CoreLib").Location;
            var locationOfSystemIOAssembly = Assembly.Load("System.IO").Location;

            var locationO1 = typeof(object).Assembly.Location;
            var locationO2 = typeof(System.Runtime.AssemblyTargetedPatchBandAttribute).Assembly.Location;
            var locationO3 = typeof(System.Text.Json.JsonSerializer).Assembly.Location;

#pragma warning restore RS1035 // Do not use APIs banned for analyzers

            if (!Debugger.IsAttached) { Debugger.Launch(); }

            CSharpCompilation compilation = CSharpCompilation.Create(
                "DynamicAssembly",
                new[] { syntaxTree },
                new[] {
                    MetadataReference.CreateFromFile(locationOfSystemAssembly),
                     MetadataReference.CreateFromFile(locationOfSystemRuntimeAssembly),
                     MetadataReference.CreateFromFile(locationOfSystemTextJsonAssembly),
                     MetadataReference.CreateFromFile(locationOfSystemPrivateCoreLibAssembly),
                     MetadataReference.CreateFromFile(locationOfSystemIOAssembly),
                },
                new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));

            using (var ms = new MemoryStream())
            {
                EmitResult result = compilation.Emit(ms);

                if (!result.Success)
                {
                    foreach (Diagnostic diagnostic in result.Diagnostics)
                    {
                        Console.WriteLine($"{diagnostic.Id}: {diagnostic.GetMessage()}");
#pragma warning disable RS1035 // Do not use APIs banned for analyzers
                        System.IO.File.WriteAllText(@$"C:\temp\err{diagnostic.Id}.txt", $@"{diagnostic.GetMessage()}");
#pragma warning restore RS1035 // Do not use APIs banned for analyzers
                    }
                    return;
                }

                ms.Seek(0, SeekOrigin.Begin);
#pragma warning disable RS1035 // Do not use APIs banned for analyzers
                Assembly assembly = Assembly.Load(ms.ToArray());
#pragma warning restore RS1035 // Do not use APIs banned for analyzers

                // Assuming you know the type and method names
                Type type = assembly.GetType("Generated.GeneratedClass");
                MethodInfo method = type.GetMethod("Use");
                object classInstance = Activator.CreateInstance(type, null);
                method.Invoke(classInstance, null);
            }
        }
    }

    /*

    public class DynamicCompiler
    {
        public void CompileAndExecute(string code)
        {
            if (!Debugger.IsAttached)
            {
                Debugger.Launch();
            }

            try
            {
                ScriptOptions options = ScriptOptions.Default
                    .AddReferences("System", "System.Core", "System.Text.Json", "System.IO")
                    .WithImports("System", "System.IO", "System.Text.Json");

                CSharpScript.EvaluateAsync(code, options);
            }
            catch (CompilationErrorException e)
            {
#pragma warning disable RS1035 // Do not use APIs banned for analyzers
                Console.WriteLine("Compilation error: " + string.Join(Environment.NewLine, e.Diagnostics));
#pragma warning restore RS1035 // Do not use APIs banned for analyzers
            }
            catch (Exception ex)
            {
                Console.WriteLine("Execution error: " + ex.Message);
            }
        }
    }
    */
}