﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace Organization.Domain.SourceGenerator10
{
    [Generator]
    public class JsonSourceFileGenerator : ISourceGenerator
    {
        private static Timer debounceTimer;
        private static readonly object lockObject = new object();
        private static bool actionPending = false;
        private static GeneratorExecutionContext latestContext;

        public void Execute(GeneratorExecutionContext context)
        {
            lock (lockObject)
            {
                latestContext = context; // Update with the latest context

                if (debounceTimer == null)
                {
                    debounceTimer = new Timer(DebouncedAction, null, Timeout.Infinite, Timeout.Infinite);
                }

                actionPending = true;
                debounceTimer.Change(10000, Timeout.Infinite); // Reset the timer to 5 seconds
            }
        }

        private void DebouncedAction(object state)
        {
            lock (lockObject)
            {
                if (actionPending)
                {
                    ExecuteIt(latestContext); // Use the latest context
                    actionPending = false;
                }
            }
        }

        public void ExecuteIt(GeneratorExecutionContext context)
        {
            if (context.SyntaxContextReceiver is SyntaxReceiver receiver)
            {
                foreach (var item in receiver.Classes)
                {
                    // Collect class information
                    string namespaceName = item.ContainingNamespace.ToDisplayString();
                    string className = item.Name;
                    string originalDefinition = item.OriginalDefinition.ToDisplayString(); ;
                    _ = context.AnalyzerConfigOptions.GlobalOptions.TryGetValue("build_property.projectdir", out var projectdir);

                    // Now, generate code that uses this class
                    string newCode = GenerateCodeUsingClass(className, originalDefinition, namespaceName, projectdir!);
                    //string classSourceCode = item.NormalizeWhitespace().ToFullString();

                    if (!Debugger.IsAttached)
                    {
                        //Debugger.Launch();
                    }

                    // Add this code to the compilation
                    context.AddSource($"JsonSourceFileClass{className}.g.cs", newCode);
                }
            }

            if (context.SyntaxContextReceiver is SyntaxReceiver3 receiver2)
            {
                foreach (var classInfo in receiver2.ClassInfo)
                {
                    _ = context.AnalyzerConfigOptions.GlobalOptions.TryGetValue("build_property.projectdir", out var projectdir);

                    SyntaxList<AttributeListSyntax> ss = classInfo.ClassDeclaration.AttributeLists;
                    var att = GetAttributePropertyValues(ss, "JsonSourceFileClass", new[] { "PropertyName" });

                    //if (!Debugger.IsAttached) { Debugger.Launch(); };

                    var modifiedClassDecl = RemoveAttributeFromClass(classInfo.ClassDeclaration, "JsonSourceFileClass");

                    // Convert the modified class declaration to a string



                    string classSourceCode = modifiedClassDecl.NormalizeWhitespace().ToFullString();

                    foreach (var item in classInfo.NestedClasses)
                    {
                        classSourceCode += " "+item.NormalizeWhitespace().ToFullString();
                    }

                    string className = modifiedClassDecl.Identifier.ValueText;
                    string filename = className + ".json";

                    var firstAttributeWithPropertyName = att.FirstOrDefault(e => e.ContainsKey("PropertyName"));
                    if (firstAttributeWithPropertyName != null)
                    {
                        filename = firstAttributeWithPropertyName["PropertyName"];
                    }

                    //if (!Debugger.IsAttached) { Debugger.Launch(); };

                    var dir = System.IO.Path.GetDirectoryName($"{projectdir}{filename}");
#pragma warning disable RS1035 // Do not use APIs banned for analyzers
                    if (!System.IO.Directory.Exists(dir))
                    {
                        System.IO.Directory.CreateDirectory(dir);
                    }
#pragma warning restore RS1035 // Do not use APIs banned for analyzers

                    var gend = StringGenerator.GenerateCodeUsingClass2("Generated", "GeneratedClass", "Main", className, filename, classSourceCode, projectdir);

                    // Now, generate code that uses this class
                    //string classSourceCode = item.NormalizeWhitespace().ToFullString();

                    try
                    {
                        StringCompiler compiler = new StringCompiler();
                        var result = compiler.CompileAndExecute(gend, "Generated", "GeneratedClass", "Main", className);
                        if (result.Count > 0)
                        {
                            //if (!Debugger.IsAttached) { Debugger.Launch(); }
#pragma warning disable RS1035 // Do not use APIs banned for analyzers
                            var text = new StringBuilder();
                            for (int i = 0; i < result.Count; i++)
                            {
                                text.Append($"//{result[i]}{Environment.NewLine}");
                            }
                            System.IO.File.WriteAllText($"{projectdir}{filename}", text.ToString());
#pragma warning restore RS1035 // Do not use APIs banned for analyzers
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
            }
        }

        private ClassDeclarationSyntax RemoveAttributeFromClass(ClassDeclarationSyntax classDecl, string attributeName)
        {
            // Filter out the attribute lists that either don't contain the target attribute
            // or are empty after removing the target attribute
            var filteredAttributeLists = classDecl.AttributeLists
                .Select(attrList => attrList.WithAttributes(SyntaxFactory.SeparatedList(
                    attrList.Attributes.Where(attr => !attr.Name.ToString().EndsWith(attributeName)))))
                .Where(attrList => attrList.Attributes.Count > 0);

            // Create a new class declaration with the filtered attribute lists
            return classDecl.WithAttributeLists(SyntaxFactory.List(filteredAttributeLists));
        }

        public void Initialize(GeneratorInitializationContext context)
        {
            //context.RegisterForSyntaxNotifications(() => new SyntaxReceiver());
            context.RegisterForSyntaxNotifications(() => new SyntaxReceiver3());
        }

        private class SyntaxReceiver : ISyntaxContextReceiver
        {
            public List<INamedTypeSymbol> Classes { get; } = new List<INamedTypeSymbol>();

            public void OnVisitSyntaxNode(GeneratorSyntaxContext context)
            {
                if (context.Node is ClassDeclarationSyntax classDeclaration)
                {
                    foreach (var attributeList in classDeclaration.AttributeLists)
                    {
                        foreach (var attribute in attributeList.Attributes)
                        {
                            if (attribute.Name.ToString().EndsWith("JsonSourceFileClass"))
                            {
                                // Get the class symbol and add it to the list
                                var classSymbol = context.SemanticModel.GetDeclaredSymbol(classDeclaration) as INamedTypeSymbol;
                                if (classSymbol != null)
                                {
                                    Classes.Add(classSymbol);
                                }
                            }
                        }
                    }
                }
            }
        }

        private class SyntaxReceiver2 : ISyntaxContextReceiver
        {
            public List<(ClassDeclarationSyntax ClassDeclaration, INamedTypeSymbol Symbol)> ClassInfo { get; } = new List<(ClassDeclarationSyntax, INamedTypeSymbol)>();

            public void OnVisitSyntaxNode(GeneratorSyntaxContext context)
            {
                if (context.Node is ClassDeclarationSyntax classDeclaration)
                {
                    foreach (var attributeList in classDeclaration.AttributeLists)
                    {
                        foreach (var attribute in attributeList.Attributes)
                        {
                            if (attribute.Name.ToString().EndsWith("JsonSourceFileClass"))
                            {
                                var classSymbol = context.SemanticModel.GetDeclaredSymbol(classDeclaration) as INamedTypeSymbol;
                                if (classSymbol != null)
                                {
                                    // Add both the class declaration syntax and the symbol to the list
                                    ClassInfo.Add((classDeclaration, classSymbol));
                                }
                            }
                        }
                    }
                }
            }
        }

        private class SyntaxReceiver3 : ISyntaxContextReceiver
        {
            public class ClassInformation
            {
                public ClassDeclarationSyntax ClassDeclaration { get; set; }
                public INamedTypeSymbol Symbol { get; set; }
                public List<ClassDeclarationSyntax> NestedClasses { get; set; } = new List<ClassDeclarationSyntax>();
            }

            public List<ClassInformation> ClassInfo { get; } = new List<ClassInformation>();

            public void OnVisitSyntaxNode(GeneratorSyntaxContext context)
            {
                if (context.Node is ClassDeclarationSyntax classDeclaration)
                {
                    ProcessClassDeclaration(context, classDeclaration);
                }
            }

            private void ProcessClassDeclaration(GeneratorSyntaxContext context, ClassDeclarationSyntax classDeclaration)
            {
                var classSymbol = context.SemanticModel.GetDeclaredSymbol(classDeclaration) as INamedTypeSymbol;
                if (classSymbol != null)
                {
                    var currentClassInfo = new ClassInformation
                    {
                        ClassDeclaration = classDeclaration,
                        Symbol = classSymbol
                    };

                    bool hasJsonSourceFileClassAttribute = classDeclaration.AttributeLists
                        .SelectMany(a => a.Attributes)
                        .Any(attr => attr.Name.ToString().EndsWith("JsonSourceFileClass"));

                    if (hasJsonSourceFileClassAttribute)
                    {
                        currentClassInfo.NestedClasses = ProcessNestedClasses(context, classDeclaration.Members);
                        ClassInfo.Add(currentClassInfo);
                    }
                }
            }

            private List<ClassDeclarationSyntax> ProcessNestedClasses(GeneratorSyntaxContext context, SyntaxList<MemberDeclarationSyntax> members)
            {
                var nestedClassDeclarations = new List<ClassDeclarationSyntax>();

                foreach (var member in members)
                {
                    if (member is ClassDeclarationSyntax nestedClass)
                    {
                        nestedClassDeclarations.Add(nestedClass);
                        nestedClassDeclarations.AddRange(ProcessNestedClasses(context, nestedClass.Members));
                    }
                    else if (member is PropertyDeclarationSyntax property)
                    {
                        var propertyTypeSymbol = context.SemanticModel.GetTypeInfo(property.Type).Type as INamedTypeSymbol;
                        if (propertyTypeSymbol != null)
                        {
                            // If it's a generic type (like List<>), check its type arguments
                            if (propertyTypeSymbol.IsGenericType)
                            {
                                foreach (var typeArgument in propertyTypeSymbol.TypeArguments.OfType<INamedTypeSymbol>())
                                {
                                    if (typeArgument.TypeKind == TypeKind.Class)
                                    {
                                        AddClassDeclarationIfNotExists(typeArgument, nestedClassDeclarations);
                                    }
                                }
                            }
                            // If it's a regular class, add it directly
                            else if (propertyTypeSymbol.TypeKind == TypeKind.Class)
                            {
                                AddClassDeclarationIfNotExists(propertyTypeSymbol, nestedClassDeclarations);
                            }
                        }
                    }
                }

                return nestedClassDeclarations;
            }

            private void AddClassDeclarationIfNotExists(INamedTypeSymbol typeSymbol, List<ClassDeclarationSyntax> nestedClassDeclarations)
            {
                var classDeclarationSyntax = FindClassDeclarationSyntax(typeSymbol);
                if (classDeclarationSyntax != null && !nestedClassDeclarations.Contains(classDeclarationSyntax))
                {
                    nestedClassDeclarations.Add(classDeclarationSyntax);
                }
            }

            private ClassDeclarationSyntax FindClassDeclarationSyntax(INamedTypeSymbol classTypeSymbol)
            {
                // Assuming 'classTypeSymbol' is not null and is of TypeKind.Class
                var declarationSyntax = classTypeSymbol.DeclaringSyntaxReferences.FirstOrDefault()?.GetSyntax() as ClassDeclarationSyntax;
                return declarationSyntax;
            }
        }

        private string GenerateCodeUsingClass(string className, string originalDefinition, string namespaceName, string projectdir)
        {
            // Generate code as a string
            return $@"
namespace {namespaceName}
{{
            public static class GeneratedClass
    {{
        public static void Use{className}()
        {{
            // Example: Instantiate the class, call a method, etc.
            var instance = new {originalDefinition}();
            var ss = System.Text.Json.JsonSerializer.Serialize<{originalDefinition}>(instance);
            System.IO.File.WriteAllText(@""{projectdir}\foo.txt"", ss);
            // ...
        }}
    }}
}}";
        }

        public void ProcessAttributeLists(SyntaxList<AttributeListSyntax> attributeLists)
        {
            foreach (var attributeList in attributeLists)
            {
                foreach (var attribute in attributeList.Attributes)
                {
                    if (attribute.Name.ToString().EndsWith("JsonSourceFileClass"))
                    {
                        // Process the attribute's arguments
                        foreach (var argument in attribute.ArgumentList.Arguments)
                        {
                            // Check if the argument is the one you're interested in
                            if (argument.NameEquals?.Name?.ToString() == "PropertyName")
                            {
                                var propertyNameValue = argument.Expression.NormalizeWhitespace().ToFullString().Trim('"');
                                // Now you have the PropertyName value
                                // You can process or store this value as needed
                            }
                        }
                    }
                }
            }
        }

        public List<Dictionary<string, string>> GetAttributePropertyValues(
    SyntaxList<AttributeListSyntax> attributeLists,
    string attributeName,
    IEnumerable<string> propertyNames)
        {
            var attributeProperties = new List<Dictionary<string, string>>();

            foreach (var attributeList in attributeLists)
            {
                foreach (var attribute in attributeList.Attributes)
                {
                    if (attribute.Name.ToString().EndsWith(attributeName))
                    {
                        var properties = new Dictionary<string, string>();

                        foreach (var argument in attribute.ArgumentList.Arguments)
                        {
                            var argumentName = argument.NameEquals?.Name?.ToString();
                            if (propertyNames.Contains(argumentName))
                            {
                                var propertyValue = argument.Expression.NormalizeWhitespace().ToFullString().Trim(new char[] { '@', '$', '"' }).Replace(@"\\", @"\\");
                                properties[argumentName] = propertyValue;
                            }
                        }

                        if (properties.Count > 0)
                        {
                            attributeProperties.Add(properties);
                        }
                    }
                }
            }

            return attributeProperties;
        }
    }
}