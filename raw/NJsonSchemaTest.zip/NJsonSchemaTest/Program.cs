﻿using ExtendedXmlSerializer;
using ExtendedXmlSerializer.Configuration;
using NJsonSchema;
using NJsonSchema.CodeGeneration.CSharp;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.Serialization;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;

namespace ConsoleApp6
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string jsonStringss = "{ \"name\": \"Carsten\", \"age\": 46 }"; // Replace with your JSON string

            string jsonStringa = $@"
        {{
       ""Settings"": {{
                ""Value1"": 1.1,
                ""Value2"": true,
                ""Subkey1"": {{
                    ""Valuef"": ""Form1"",
                    ""Valuex"": ""Form1""
                }},
                ""cars"": [""Ford"", ""BMW"", ""dvdv""]
            }}
        }}
        ";

            CultureSpecificFiles ss = FindAllCultureSpecificFiles("C:\\Users\\Valgrind\\source\\repos\\ConsoleApp6\\", "foo.json");

            var result1 = ss.MergeApplicableJsonFiles().ToString();

            string jsonFile = ss.GetDefaultFile().FilePath;

            string jsonString = System.IO.File.ReadAllText(jsonFile);

            var ssd = System.Text.Json.JsonSerializer.Deserialize<Classx>(jsonString);

            JsonSchema schema = JsonSchema.FromSampleJson(jsonString);
            schema.Title = "MyRessourceGenerated";

            SetAllowAdditionalProperties(schema, false);

            string schemaData = schema.ToJson();

            var settings = new CSharpGeneratorSettings
            {
                JsonLibrary = CSharpJsonLibrary.SystemTextJson,
                Namespace = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name,
                ArrayType = "List",
            };

            var generator = new CSharpGenerator(schema, settings);

            var file = generator.GenerateFile();

            System.IO.File.WriteAllText(jsonFile + ".cs", file);

            MyRessourceGenerated Resources = System.Text.Json.JsonSerializer.Deserialize<MyRessourceGenerated>(result1)!;

            Console.WriteLine(schemaData);

            Console.WriteLine("Hello, World!");

            Class1.testing();

            XmlSerializer serializer = new XmlSerializer(typeof(MyRessourceGenerated));

            Debug.WriteLine($@"test {Resources.Other.Num}");
            var sedfs = Resources.Other.Entry1;

            MyRessourceGenerated xx = ObjectInitializer.NewInitialized<MyRessourceGenerated>(true);

            IExtendedXmlSerializer serializerss = new ConfigurationContainer().UseAutoFormatting()
                                                                .UseOptimizedNamespaces()
                                                                .EnableImplicitTyping(typeof(MyRessourceGenerated))
                                                                // Additional configurations...
                                                                .Create();

            // Configure ExtendedXmlSerializer
            var serializers = new ConfigurationContainer()
                .EnableImplicitTyping(typeof(MyRessourceGenerated))
                .Create();

            var document = serializers.Serialize(new XmlWriterSettings { Indent = true },
                                                xx);

            Console.WriteLine(document);

            // Serialize the object to a string
            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, xx);
                string xml = writer.ToString();
                Console.WriteLine(xml);
            }
        }

        private static void SerializeWithDataContractSerializer<T>(T obj)
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(T));

            using (StringWriter stringWriter = new StringWriter())
            using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter))
            {
                serializer.WriteObject(xmlWriter, obj);
                string xml = stringWriter.ToString();
                Console.WriteLine(xml);
            }
        }

        private static void SetAllowAdditionalProperties(JsonSchema schema, bool allow)
        {
            schema.AllowAdditionalProperties = allow;
            foreach (var property in schema.Properties)
            {
                SetAllowAdditionalProperties(property.Value.ActualSchema, allow);
            }
        }

        public static CultureSpecificFiles FindAllCultureSpecificFiles(string directoryPath, string defaultFileName)
        {
            var cultureSpecificFiles = new CultureSpecificFiles();
            var availableCultures = CultureInfo.GetCultures(CultureTypes.AllCultures);

            // Extract base file name and extension
            string baseFileName = Path.GetFileNameWithoutExtension(defaultFileName);
            string extension = Path.GetExtension(defaultFileName);

            // Add the default file if it exists
            string defaultFilePath = Path.Combine(directoryPath, defaultFileName);
            if (File.Exists(defaultFilePath))
            {
                cultureSpecificFiles.Add(defaultFilePath, CultureInfo.InvariantCulture); // Using InvariantCulture for default
            }

            foreach (string filePath in Directory.EnumerateFiles(directoryPath, baseFileName + ".*" + extension))
            {
                string fileName = Path.GetFileNameWithoutExtension(filePath);
                if (fileName.Equals(baseFileName)) continue; // Skip the default file already added

                string cultureName = fileName.Substring(baseFileName.Length + 1);
                foreach (var culture in availableCultures)
                {
                    if (cultureName.Equals(culture.Name, StringComparison.OrdinalIgnoreCase) || cultureName.Equals(culture.TwoLetterISOLanguageName, StringComparison.OrdinalIgnoreCase))
                    {
                        cultureSpecificFiles.Add(filePath, culture);
                        break;
                    }
                }
            }

            return cultureSpecificFiles;
        }

        private static void JustAndIdea()
        {
            JsonNode data2 = JsonSerializer.Deserialize<JsonNode>($@"
        {{
       ""Settings"": {{
                ""Value1"": 1,
                ""Value2"": true,
                ""Subkey1"": {{
                    ""Value1"": ""Form1""
                }}
            }}
        }}
        ");

            JsonNode settings = data2["Settings"];

            var value1 = settings["Value1"].GetValue<int>();
            var value2 = settings["Value2"].GetValue<bool>();

            JsonNode subkey1 = settings["Subkey1"];
            var subkey1Value1 = subkey1["Value1"].GetValue<string>();

            Debug.WriteLine($"Value1: {value1}");
            Debug.WriteLine($"Value2: {value2}");
            Debug.WriteLine($"Subkey1 -> Value1: {subkey1Value1}");

            var settingsValue1 = data2["Settings"]["Value1"].GetValue<int>();

            var settingsValueX = data2["Settings"]?["Value1"]?.GetValue<int>();
            var settingsValueY = data2["Settings"]?["Value2"]?.GetValue<object>().ToString();
            var settingsValueZ = data2["Settings"]?["Value3"]?.GetValue<object>().ToString();

            static T GetValueFromPath<T>(JsonNode node, string path)
            {
                string[] parts = path.Split('.');
                JsonNode current = node;

                foreach (var part in parts)
                {
                    if (current == null) return default(T);
                    current = current[part];
                }

                return current == null ? default(T) : current.GetValue<T>();
            }

            static object GetValueFromPath2(JsonNode node, string path)
            {
                string[] parts = path.Split('.');
                JsonNode current = node;

                foreach (var part in parts)
                {
                    if (current == null) return null;
                    current = current[part];
                }

                return current?.GetValue<object>();
            }

            static string GetStringFromPath3(JsonNode node, string path)
            {
                var value = GetValueFromPath2(node, path);
                return value?.ToString();
            }

            Debug.WriteLine($"Settings -> Value1: {settingsValue1}");

            //JsonObject? ss2 = data2[0].AsObject();
            //var sddf = ss.GetValue<int>();

            //json.Print();

            Debug.WriteLine($"---------------");

            // Recursive function to iterate over JSON elements
            void IterateJson(JsonNode node, string path)
            {
                if (node == null) return;

                // Check if the node is an object or an array
                if (node is JsonObject || node is JsonArray)
                {
                    foreach (var child in node.AsObject())
                    {
                        // Recursive call to iterate through child nodes
                        IterateJson(child.Value, path + child.Key + ".");
                    }
                }
                else
                {
                    // Print the path and value of the node
                    Debug.WriteLine($"Key: {path} , Value: {node}");
                }
            }

            // Start iterating from the root node
            IterateJson(data2, "");

            var settingsValueTEST1 = GetValueFromPath<object>(data2, "Settings.Value2")?.ToString();

            var settingsValueTEST2 = GetStringFromPath3(data2, "Settings.Subkey1.Value1");
            var settingsValueTEST3 = GetStringFromPath3(data2, "Settings.Subkey1.Value2");
            var settingsValueTEST4 = GetStringFromPath3(data2, "Settings.Subkey1.Value3");

            string inputText = "Some text with {{Settings.Subkey1.Value1}} and {{Settings.Value2}}, also {{Settings.Value1}}";

            string pattern = @"{{([a-z0-9A-Z\\.:]+)}}";

            // Access Match Groups
            MatchCollection matches = Regex.Matches(inputText, pattern);
            foreach (Match match in matches)
            {
                Debug.WriteLine("Found: " + match.Value);
                if (match.Groups.Count > 1) // Check if the capturing group is present
                {
                    string captured = match.Groups[1].Value; // Group 1 is the first capturing group
                    Debug.WriteLine("Captured: " + captured);

                    var data = GetStringFromPath3(data2, captured);

                    if (data != null)
                    {
                        //Better here cut and insert
                        inputText = inputText.Replace(match.Value, data);
                    }
                }
            }

            var allreplaced = Regex.Matches(inputText, pattern);
            foreach (Match match in allreplaced)
            {
                Debug.WriteLine("Not replaced: " + match.Value);
            }

            Debug.WriteLine(inputText);
        }
    }
}