﻿using System.Text.Json;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;

namespace ConsoleApp1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }

        public class Subclass1
        {
            public int MyA { get; set; }
            public int MyB { get; set; }
            public List<int> MyC { get; set; } = new List<int>() { 1, 2 };
        }


        public class Subclass
        {
            public int MyA { get; set; }
            public int MyB { get; set; }
            public List<Subclass1> MyC { get; set; } = new List<Subclass1>() { new Subclass1() { MyA = 2 }};
        }

        [JsonSourceFileClass(PropertyName = "File3.json")]
        public class Dataxs
        {
            public int Aa { get; set; }
            public int B { get; set; }
            public List<Subclass> C { get; set; } = new List<Subclass>(){ new Subclass() { MyA = 1, MyB = 2 } } ;
        }

        public class Level1
        {
            public int MyA { get; set; }
            public int MyBs { get; set; }
            public List<int> MyC { get; set; } = new List<int>() { 2 };
        }

        [JsonSourceFileClass(PropertyName = "File35.json")]
        public class DataToplevel
        {
            public int Aa { get; set; }
            public int Bjgs { get; set; }
            public List<Level1> C { get; set; } = new List<Level1>() { new Level1() { MyA = 1, MyBs = 2 }, new Level1() { MyA = 5, MyBs = 5 } };
        }
    }

}
