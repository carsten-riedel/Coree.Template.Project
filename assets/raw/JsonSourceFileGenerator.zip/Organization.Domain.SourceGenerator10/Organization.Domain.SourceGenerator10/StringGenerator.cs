﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Organization.Domain.SourceGenerator10
{
    internal static class StringGenerator
    {
        internal static string GenerateCodeUsingClass2(string namespaceName, string typeName,string methodName, string InjectedClassName,string filename, string InjectedClassSourceCode, string projectdir)
        {

            // Generate code as a string
            return $@"
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace {namespaceName}
{{

    {InjectedClassSourceCode}

    public class {typeName}
    {{
        public void {methodName}()
        {{
            var instance = new {InjectedClassName}();
            var jsonSerializerOptions = new System.Text.Json.JsonSerializerOptions(){{WriteIndented = true}};
            var jsonString = System.Text.Json.JsonSerializer.Serialize<{InjectedClassName}>(instance,jsonSerializerOptions);
            System.IO.File.WriteAllText(@""{projectdir}{filename}"", jsonString);
        }}
    }}
   
}}
";
        }
    }
}
