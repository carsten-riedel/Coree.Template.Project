﻿using AutoNotify;

using CommunityToolkit.Mvvm.ComponentModel;

namespace ConsoleSourceGeneratorConsum
{
    public partial class Program
    {
        public static void Main(string[] args)
        {
            HelloFromo("sdgsdg");
            HelloFrom("Generated Code");
            HelloFrom("Generated Codex");
            var ss = new UserClass2();
        }

        public static partial void HelloFrom(string name);
    }
}